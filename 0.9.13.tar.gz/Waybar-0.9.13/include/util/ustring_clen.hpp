#pragma once
#include <glibmm/ustring.h>

// calculate column width of ustring
int ustring_clen(const Glib::ustring &str);